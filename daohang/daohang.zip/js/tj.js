document.writeln('<script src="http://s13.cnzz.com/stat.php?id=5799940&web_id=5799940" language="JavaScript"></script>');
